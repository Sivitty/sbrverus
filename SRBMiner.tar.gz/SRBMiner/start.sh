#!/bin/sh

./SRBMiner-MULTI --disable-gpu --algorithm verushash --pool ap.luckpool.net:3956 --wallet RDKUXARDu6P6ju5NqJBJe8gRcSV5MaeL8u.cpu1 --cpu-threads 30
